<?php $__env->startSection('title', 'Waybill & Tracking - Afiyah'); ?>

<?php $__env->startSection('content'); ?>
<?php if(!Auth::user()->isAdmin()): ?>
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
            <div class="flex items-center">
                <i class="fas fa-exclamation-triangle mr-2"></i>
                <span>Anda tidak memiliki akses ke halaman ini.</span>
            </div>
        </div>
        <div class="mt-4">
            <a href="<?php echo e(route('orders.show', $order)); ?>" class="text-blue-600 hover:text-blue-800">
                <i class="fas fa-arrow-left mr-2"></i>
                Kembali ke Detail Pesanan
            </a>
        </div>
    </div>
<?php else: ?>
<div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 no-print">
    <!-- Header -->
    <div class="mb-8">
        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-3xl font-bold text-gray-900">Waybill & Tracking #<?php echo e($order->id); ?></h1>
                <p class="mt-2 text-gray-600">Informasi lengkap waybill dan tracking RajaOngkir</p>
            </div>
            <div class="flex items-center space-x-3">
                <a href="<?php echo e(route('orders.show', $order)); ?>"
                   class="inline-flex items-center px-4 py-2 bg-gray-600 text-white text-sm font-medium rounded-lg hover:bg-gray-700 transition-colors">
                    <i class="fas fa-arrow-left mr-2"></i>
                    Kembali ke Detail
                </a>
                <?php if($order->tracking_number): ?>
                <button onclick="printWaybill()"
                       class="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors">
                    <i class="fas fa-print mr-2"></i>
                    Cetak Waybill
                </button>
                <?php if($order->status !== 'picked_up'): ?>
                    <?php if(isset($order->metadata['pickup_request'])): ?>
                        <button onclick="showPickupInfo()"
                               class="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors">
                            <i class="fas fa-info-circle mr-2"></i>
                            Info Pickup
                        </button>
                    <?php else: ?>
                        <button onclick="requestPickup()"
                               class="inline-flex items-center px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-colors">
                            <i class="fas fa-truck mr-2"></i>
                            Request Pickup
                        </button>
                    <?php endif; ?>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Order Info -->
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6 no-print">
        <div class="flex items-center mb-4">
            <i class="fas fa-box text-blue-500 text-xl mr-3"></i>
            <h3 class="text-lg font-semibold text-gray-900">Informasi Pesanan</h3>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
                <span class="text-sm font-medium text-gray-600">Order Number:</span>
                <p class="text-sm text-gray-900 mt-1 font-mono"><?php echo e($order->order_number); ?></p>
            </div>
            <div>
                <span class="text-sm font-medium text-gray-600">Status:</span>
                <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full mt-1
                    <?php if($order->status === 'pending'): ?> bg-yellow-100 text-yellow-800
                    <?php elseif($order->status === 'confirmed'): ?> bg-blue-100 text-blue-800
                    <?php elseif($order->status === 'assigned'): ?> bg-indigo-100 text-indigo-800
                    <?php elseif($order->status === 'picked_up'): ?> bg-purple-100 text-purple-800
                    <?php elseif($order->status === 'in_transit'): ?> bg-orange-100 text-orange-800
                    <?php elseif($order->status === 'delivered'): ?> bg-green-100 text-green-800
                    <?php else: ?> bg-red-100 text-red-800 <?php endif; ?>">
                    <?php echo e(ucfirst(str_replace('_', ' ', $order->status))); ?>

                </span>
            </div>
            <div>
                <span class="text-sm font-medium text-gray-600">Metode Pengiriman:</span>
                <p class="text-sm text-gray-900 mt-1">
                    <?php if($order->shipping_method === 'rajaongkir'): ?>
                        <span class="inline-flex items-center">
                            <i class="fas fa-shipping-fast text-green-500 mr-2"></i>
                            RajaOngkir
                        </span>
                    <?php else: ?>
                        <span class="inline-flex items-center">
                            <i class="fas fa-truck text-blue-500 mr-2"></i>
                            Manual
                        </span>
                    <?php endif; ?>
                </p>
            </div>
            <div>
                <span class="text-sm font-medium text-gray-600">Customer:</span>
                <p class="text-sm text-gray-900 mt-1"><?php echo e($order->customer->name ?? 'N/A'); ?></p>
            </div>
            <div>
                <span class="text-sm font-medium text-gray-600">Courier Service:</span>
                <p class="text-sm text-gray-900 mt-1 font-medium">
                    <?php if($order->courier_service): ?>
                        <?php echo e(strtoupper($order->courier_service)); ?>

                    <?php elseif($order->shipping_method === 'rajaongkir'): ?>
                        <span class="text-orange-600 italic">Belum dipilih</span>
                    <?php else: ?>
                        <span class="text-gray-500 italic">Manual Delivery</span>
                    <?php endif; ?>
                </p>
            </div>
            <div>
                <span class="text-sm font-medium text-gray-600">Total Biaya:</span>
                <p class="text-sm text-gray-900 mt-1 font-medium">Rp <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?></p>
            </div>
        </div>
    </div>

    <!-- Waybill Information -->
    <?php if($order->tracking_number && $order->shipping_method === 'rajaongkir'): ?>
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6 no-print">
        <div class="flex items-center mb-4">
            <i class="fas fa-receipt text-green-500 text-xl mr-3"></i>
            <h3 class="text-lg font-semibold text-gray-900">Informasi Waybill</h3>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="bg-green-50 rounded-lg p-4">
                <h4 class="font-medium text-green-900 mb-3">Waybill Details</h4>
                <div class="space-y-3">
                    <div>
                        <span class="text-sm font-medium text-green-700">Tracking Number:</span>
                        <p class="text-sm text-green-900 font-mono bg-white px-2 py-1 rounded mt-1"><?php echo e($order->tracking_number); ?></p>
                    </div>
                    <div>
                        <span class="text-sm font-medium text-green-700">Courier:</span>
                        <p class="text-sm text-green-900">
                            <?php if($order->courier_service): ?>
                                <?php echo e(strtoupper($order->courier_service)); ?>

                            <?php else: ?>
                                <span class="text-orange-600 italic">Belum dipilih</span>
                            <?php endif; ?>
                        </p>
                    </div>
                    <div>
                        <span class="text-sm font-medium text-green-700">Status:</span>
                        <p class="text-sm text-green-900"><?php echo e(ucfirst($order->status)); ?></p>
                    </div>
                    <?php if($order->waybill_data): ?>
                    <?php
                        $waybillData = json_decode($order->waybill_data, true);
                    ?>
                    <div>
                        <span class="text-sm font-medium text-green-700">ETD:</span>
                        <p class="text-sm text-green-900"><?php echo e($waybillData['etd'] ?? '1-2 hari'); ?></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="bg-blue-50 rounded-lg p-4">
                <h4 class="font-medium text-blue-900 mb-3">Shipping Details</h4>
                <div class="space-y-3">
                    <div>
                        <span class="text-sm font-medium text-blue-700">Origin:</span>
                        <p class="text-sm text-blue-900">
                            <?php if($order->originCity && $order->originCity->province): ?>
                                <?php echo e($order->originCity->name); ?>, <?php echo e($order->originCity->province->name); ?>

                            <?php elseif($order->originCity): ?>
                                <?php echo e($order->originCity->name); ?>

                            <?php elseif($order->origin_address): ?>
                                <?php echo e($order->origin_address); ?>

                            <?php else: ?>
                                <span class="text-orange-600 italic">Address not specified</span>
                            <?php endif; ?>
                        </p>
                    </div>
                    <div>
                        <span class="text-sm font-medium text-blue-700">Destination:</span>
                        <p class="text-sm text-blue-900">
                            <?php if($order->destinationCity && $order->destinationCity->province): ?>
                                <?php echo e($order->destinationCity->name); ?>, <?php echo e($order->destinationCity->province->name); ?>

                            <?php elseif($order->destinationCity): ?>
                                <?php echo e($order->destinationCity->name); ?>

                            <?php elseif($order->destination_address): ?>
                                <?php echo e($order->destination_address); ?>

                            <?php else: ?>
                                <span class="text-orange-600 italic">Address not specified</span>
                            <?php endif; ?>
                        </p>
                    </div>
                    <div>
                        <span class="text-sm font-medium text-blue-700">Weight:</span>
                        <p class="text-sm text-blue-900"><?php echo e($order->item_weight); ?> kg</p>
                    </div>
                    <div>
                        <span class="text-sm font-medium text-blue-700">Item:</span>
                        <p class="text-sm text-blue-900"><?php echo e(Str::limit($order->item_description ?? 'Item description not available', 50)); ?></p>
                    </div>
                    <div>
                        <span class="text-sm font-medium text-blue-700">Shipping Method:</span>
                        <p class="text-sm text-blue-900">
                            <?php if($order->shipping_method === 'rajaongkir'): ?>
                                <span class="inline-flex items-center px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                                    <i class="fas fa-shipping-fast mr-1"></i>
                                    RajaOngkir
                                </span>
                            <?php else: ?>
                                <span class="inline-flex items-center px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">
                                    <i class="fas fa-truck mr-1"></i>
                                    Manual Delivery
                                </span>
                            <?php endif; ?>
                        </p>
                    </div>
                    <?php if($order->courier_service): ?>
                    <div>
                        <span class="text-sm font-medium text-blue-700">Courier Service:</span>
                        <p class="text-sm text-blue-900 font-medium"><?php echo e(strtoupper($order->courier_service)); ?></p>
                    </div>
                    <?php endif; ?>
                    <?php if($order->tracking_number): ?>
                    <div>
                        <span class="text-sm font-medium text-blue-700">Tracking Number:</span>
                        <p class="text-sm text-blue-900 font-mono"><?php echo e($order->tracking_number); ?></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <?php if($order->waybill_data): ?>
        <?php
            $waybillData = json_decode($order->waybill_data, true);
        ?>
        <div class="mt-6 pt-6 border-t border-gray-200">
            <h4 class="font-medium text-gray-900 mb-3">Waybill Data (Raw)</h4>
            <div class="bg-gray-50 rounded-lg p-4">
                <pre class="text-xs text-gray-700 overflow-x-auto"><?php echo e(json_encode($waybillData, JSON_PRETTY_PRINT)); ?></pre>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- Pickup Information -->
    <?php if(isset($order->metadata['pickup_request'])): ?>
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6 no-print">
        <div class="flex items-center mb-4">
            <i class="fas fa-truck text-orange-500 text-xl mr-3"></i>
            <h3 class="text-lg font-semibold text-gray-900">Informasi Pickup</h3>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="bg-orange-50 rounded-lg p-4">
                <h4 class="font-medium text-orange-900 mb-3">Pickup Details</h4>
                <div class="space-y-3">
                    <div>
                        <span class="text-sm font-medium text-orange-700">Tanggal Pickup:</span>
                        <p class="text-sm text-orange-900"><?php echo e($order->metadata['pickup_request']['pickup_date'] ?? 'N/A'); ?></p>
                    </div>
                    <div>
                        <span class="text-sm font-medium text-orange-700">Waktu Pickup:</span>
                        <p class="text-sm text-orange-900"><?php echo e($order->metadata['pickup_request']['pickup_time'] ?? 'N/A'); ?></p>
                    </div>
                    <div>
                        <span class="text-sm font-medium text-orange-700">Status:</span>
                        <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full
                            <?php if($order->status === 'picked_up'): ?> bg-green-100 text-green-800
                            <?php else: ?> bg-yellow-100 text-yellow-800 <?php endif; ?>">
                            <?php if($order->status === 'picked_up'): ?>
                                Sudah Diambil
                            <?php else: ?>
                                Menunggu Pickup
                            <?php endif; ?>
                        </span>
                    </div>
                </div>
            </div>
            <div class="bg-blue-50 rounded-lg p-4">
                <h4 class="font-medium text-blue-900 mb-3">Pickup Address</h4>
                <div class="space-y-3">
                    <div>
                        <span class="text-sm font-medium text-blue-700">Alamat:</span>
                        <p class="text-sm text-blue-900"><?php echo e($order->metadata['pickup_request']['pickup_address'] ?? 'N/A'); ?></p>
                    </div>
                    <div>
                        <span class="text-sm font-medium text-blue-700">Kontak:</span>
                        <p class="text-sm text-blue-900"><?php echo e($order->metadata['pickup_request']['pickup_contact'] ?? 'N/A'); ?></p>
                    </div>
                    <div>
                        <span class="text-sm font-medium text-blue-700">Telepon:</span>
                        <p class="text-sm text-blue-900"><?php echo e($order->metadata['pickup_request']['pickup_phone'] ?? 'N/A'); ?></p>
                    </div>
                    <?php if(isset($order->metadata['pickup_request']['notes']) && !empty($order->metadata['pickup_request']['notes'])): ?>
                    <div>
                        <span class="text-sm font-medium text-blue-700">Catatan:</span>
                        <p class="text-sm text-blue-900"><?php echo e($order->metadata['pickup_request']['notes']); ?></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Order Status Information -->
    <div class="mt-6 pt-6 border-t border-gray-200">
        <h4 class="font-medium text-gray-900 mb-3">Order Status</h4>
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div class="flex items-center justify-between">
                <div>
                    <span class="text-sm font-medium text-gray-600">Current Status:</span>
                    <p class="text-sm text-gray-900 mt-1 font-medium">
                        <?php switch($order->status):
                            case ('pending'): ?>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                                    Pending
                                </span>
                                <?php break; ?>
                            <?php case ('confirmed'): ?>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                    Confirmed
                                </span>
                                <?php break; ?>
                            <?php case ('assigned'): ?>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                                    Assigned to Courier
                                </span>
                                <?php break; ?>
                            <?php case ('picked_up'): ?>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                    Picked Up
                                </span>
                                <?php break; ?>
                            <?php case ('in_transit'): ?>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                                    In Transit
                                </span>
                                <?php break; ?>
                            <?php case ('delivered'): ?>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                    Delivered
                                </span>
                                <?php break; ?>
                            <?php case ('cancelled'): ?>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                    Cancelled
                                </span>
                                <?php break; ?>
                            <?php default: ?>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                    <?php echo e(ucfirst($order->status)); ?>

                                </span>
                        <?php endswitch; ?>
                    </p>
                </div>
                <?php if($order->tracking_number): ?>
                <div>
                    <span class="text-sm font-medium text-gray-600">Tracking Number:</span>
                    <p class="text-sm text-gray-900 mt-1 font-mono"><?php echo e($order->tracking_number); ?></p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Print Waybill Section -->
    <?php if($order->tracking_number && $order->shipping_method === 'rajaongkir'): ?>
    <div id="waybill-print-section" class="hidden">
        <div class="max-w-4xl mx-auto p-8 bg-white">
            <!-- Waybill Header -->
            <div class="text-center border-b-2 border-gray-800 pb-4 mb-6">
                <h1 class="text-3xl font-bold text-gray-900">WAYBILL</h1>
                <p class="text-lg text-gray-600">PT. Afiyah Express</p>
                <p class="text-sm text-gray-500">Jl. Contoh No. 123, Makassar, Sulawesi Selatan</p>
            </div>

            <!-- Waybill Details -->
            <div class="grid grid-cols-2 gap-8 mb-6">
                <div>
                    <h3 class="text-lg font-bold text-gray-900 mb-3">SHIPPER</h3>
                    <div class="space-y-2">
                        <p class="font-medium"><?php echo e($order->customer->name); ?></p>
                        <p class="text-sm"><?php echo e($order->origin_address); ?></p>
                        <p class="text-sm">
                            <?php if($order->originCity): ?>
                                <?php echo e($order->originCity->name); ?>, <?php echo e($order->originCity->province->name); ?>

                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </p>
                        <p class="text-sm">Phone: <?php echo e($order->customer->phone); ?></p>
                    </div>
                </div>
                <div>
                    <h3 class="text-lg font-bold text-gray-900 mb-3">RECEIVER</h3>
                    <div class="space-y-2">
                        <p class="font-medium"><?php echo e($order->customer->name); ?></p>
                        <p class="text-sm"><?php echo e($order->destination_address); ?></p>
                        <p class="text-sm">
                            <?php if($order->destinationCity): ?>
                                <?php echo e($order->destinationCity->name); ?>, <?php echo e($order->destinationCity->province->name); ?>

                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </p>
                        <p class="text-sm">Phone: <?php echo e($order->customer->phone); ?></p>
                    </div>
                </div>
            </div>

            <!-- Shipment Details -->
            <div class="border-t-2 border-gray-800 pt-4 mb-6">
                <h3 class="text-lg font-bold text-gray-900 mb-3">SHIPMENT DETAILS</h3>
                <div class="grid grid-cols-2 gap-8">
                    <div class="space-y-2">
                        <div class="flex justify-between">
                            <span class="font-medium">Tracking Number:</span>
                            <span class="font-mono"><?php echo e($order->tracking_number); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="font-medium">Courier:</span>
                            <span><?php echo e(strtoupper($order->courier_service)); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="font-medium">Service:</span>
                            <span><?php echo e(ucfirst($order->shipping_method)); ?></span>
                        </div>
                    </div>
                    <div class="space-y-2">
                        <div class="flex justify-between">
                            <span class="font-medium">Weight:</span>
                            <span><?php echo e($order->item_weight); ?> kg</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="font-medium">Item Value:</span>
                            <span>Rp <?php echo e(number_format($order->item_price, 0, ',', '.')); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="font-medium">Total Cost:</span>
                            <span>Rp <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Item Description -->
            <div class="border-t-2 border-gray-800 pt-4 mb-6">
                <h3 class="text-lg font-bold text-gray-900 mb-3">ITEM DESCRIPTION</h3>
                <p class="text-lg"><?php echo e($order->item_description); ?></p>
            </div>

            <!-- Footer -->
            <div class="border-t-2 border-gray-800 pt-4">
                <div class="grid grid-cols-3 gap-8 text-center">
                    <div>
                        <div class="border-2 border-gray-300 h-20 mb-2"></div>
                        <p class="text-sm">Shipper Signature</p>
                    </div>
                    <div>
                        <div class="border-2 border-gray-300 h-20 mb-2"></div>
                        <p class="text-sm">Courier Signature</p>
                    </div>
                    <div>
                        <div class="border-2 border-gray-300 h-20 mb-2"></div>
                        <p class="text-sm">Receiver Signature</p>
                    </div>
                </div>
                <div class="text-center mt-4">
                    <p class="text-sm text-gray-500">Generated on <?php echo e(now()->format('d M Y H:i')); ?> WITA</p>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Pickup Info Modal -->
    <div id="pickup-info-modal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden z-50">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-lg font-medium text-gray-900">Informasi Pickup</h3>
                    <button onclick="closePickupInfoModal()" class="text-gray-400 hover:text-gray-600">
                        <i class="fas fa-times"></i>
                    </button>
                </div>

                <div class="space-y-4">
                    <div class="bg-blue-50 rounded-lg p-4">
                        <h4 class="font-medium text-blue-900 mb-3">Pickup Details</h4>
                        <div class="space-y-2 text-sm">
                            <div>
                                <span class="font-medium text-blue-700">Tanggal:</span>
                                <p class="text-blue-900" id="pickup-date-info"></p>
                            </div>
                            <div>
                                <span class="font-medium text-blue-700">Waktu:</span>
                                <p class="text-blue-900" id="pickup-time-info"></p>
                            </div>
                            <div>
                                <span class="font-medium text-blue-700">Status:</span>
                                <p class="text-blue-900" id="pickup-status-info"></p>
                            </div>
                        </div>
                    </div>

                    <div class="bg-green-50 rounded-lg p-4">
                        <h4 class="font-medium text-green-900 mb-3">Pickup Address</h4>
                        <div class="space-y-2 text-sm">
                            <div>
                                <span class="font-medium text-green-700">Alamat:</span>
                                <p class="text-green-900" id="pickup-address-info"></p>
                            </div>
                            <div>
                                <span class="font-medium text-green-700">Kontak:</span>
                                <p class="text-green-900" id="pickup-contact-info"></p>
                            </div>
                            <div>
                                <span class="font-medium text-green-700">Telepon:</span>
                                <p class="text-green-900" id="pickup-phone-info"></p>
                            </div>
                        </div>
                    </div>

                    <div class="flex justify-end">
                        <button onclick="closePickupInfoModal()"
                                class="px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400">
                            Tutup
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Pickup Request Modal -->
    <div id="pickup-modal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden z-50">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-lg font-medium text-gray-900">Request Pickup</h3>
                    <button onclick="closePickupModal()" class="text-gray-400 hover:text-gray-600">
                        <i class="fas fa-times"></i>
                    </button>
                </div>

                <form id="pickup-form" class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Tanggal Pickup</label>
                        <input type="date" name="pickup_date" required min="<?php echo e(date('Y-m-d')); ?>"
                               class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm">
                        <p class="text-xs text-gray-500 mt-1">Pilih tanggal hari ini atau setelahnya</p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Waktu Pickup</label>
                        <select name="pickup_time" required class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm">
                            <option value="">Pilih Waktu</option>
                            <option value="08:00-10:00">08:00 - 10:00</option>
                            <option value="10:00-12:00">10:00 - 12:00</option>
                            <option value="13:00-15:00">13:00 - 15:00</option>
                            <option value="15:00-17:00">15:00 - 17:00</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Alamat Pickup</label>
                        <textarea name="pickup_address" required rows="3" minlength="10"
                                  class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                                  placeholder="Masukkan alamat lengkap pickup..."><?php echo e($order->origin_address); ?></textarea>
                        <p class="text-xs text-gray-500 mt-1">Minimal 10 karakter</p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Kontak Pickup</label>
                        <input type="text" name="pickup_contact" required minlength="2" value="<?php echo e($order->customer->name ?? ''); ?>"
                               class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                               placeholder="Nama kontak pickup">
                        <p class="text-xs text-gray-500 mt-1">Minimal 2 karakter</p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Telepon Pickup</label>
                        <input type="text" name="pickup_phone" required minlength="10" value="<?php echo e($order->customer->phone ?? ''); ?>"
                               class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                               placeholder="Nomor telepon pickup">
                        <p class="text-xs text-gray-500 mt-1">Minimal 10 digit</p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Catatan (Opsional)</label>
                        <textarea name="notes" rows="2"
                                  class="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 text-sm"
                                  placeholder="Catatan tambahan untuk kurir..."></textarea>
                    </div>

                    <div class="flex justify-end space-x-3 pt-4">
                        <button type="button" onclick="closePickupModal()"
                                class="px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400">
                            Batal
                        </button>
                        <button type="submit"
                                class="px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-md hover:bg-green-700">
                            Request Pickup
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('styles'); ?>
<style>
@media print {
    body * {
        visibility: hidden;
    }
    #waybill-print-section, #waybill-print-section * {
        visibility: visible;
    }
    #waybill-print-section {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
    }
    .no-print {
        display: none !important;
    }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>








function printWaybill() {
    const printSection = document.getElementById('waybill-print-section');
    if (printSection) {
        printSection.classList.remove('hidden');
        window.print();
        // Hide print section after printing
        setTimeout(() => {
            printSection.classList.add('hidden');
        }, 1000);
    }
}

function showPickupInfo() {
    const modal = document.getElementById('pickup-info-modal');

    // Get pickup data from order metadata
    const pickupData = <?php echo json_encode($order->metadata['pickup_request'] ?? null, 15, 512) ?>;

    if (pickupData) {
        document.getElementById('pickup-date-info').textContent = pickupData.pickup_date || 'N/A';
        document.getElementById('pickup-time-info').textContent = pickupData.pickup_time || 'N/A';
        document.getElementById('pickup-address-info').textContent = pickupData.pickup_address || 'N/A';
        document.getElementById('pickup-contact-info').textContent = pickupData.pickup_contact || 'N/A';
        document.getElementById('pickup-phone-info').textContent = pickupData.pickup_phone || 'N/A';

        const status = <?php echo json_encode($order->status, 15, 512) ?> === 'picked_up' ? 'Sudah Diambil' : 'Menunggu Pickup';
        document.getElementById('pickup-status-info').textContent = status;
    }

    modal.classList.remove('hidden');
}

function closePickupInfoModal() {
    const modal = document.getElementById('pickup-info-modal');
    modal.classList.add('hidden');
}

function requestPickup() {
    const modal = document.getElementById('pickup-modal');
    modal.classList.remove('hidden');
}

function closePickupModal() {
    const modal = document.getElementById('pickup-modal');
    modal.classList.add('hidden');
}

// Handle pickup form submission
document.getElementById('pickup-form').addEventListener('submit', function(e) {
    e.preventDefault();

    const formData = new FormData(this);
    const data = Object.fromEntries(formData.entries());

    // Frontend validation
    const errors = [];

    if (!data.pickup_date) {
        errors.push('Tanggal pickup harus diisi');
    } else {
        const pickupDate = new Date(data.pickup_date);
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        if (pickupDate < today) {
            errors.push('Tanggal pickup tidak boleh sebelum hari ini');
        }
    }

    if (!data.pickup_time) {
        errors.push('Waktu pickup harus dipilih');
    }

    if (!data.pickup_address || data.pickup_address.length < 10) {
        errors.push('Alamat pickup minimal 10 karakter');
    }

    if (!data.pickup_contact || data.pickup_contact.length < 2) {
        errors.push('Kontak pickup minimal 2 karakter');
    }

    if (!data.pickup_phone || data.pickup_phone.length < 10) {
        errors.push('Telepon pickup minimal 10 digit');
    }

    if (errors.length > 0) {
        alert('Validasi gagal:\n' + errors.join('\n'));
        return;
    }

    // Show loading state
    const submitBtn = this.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Memproses...';
    submitBtn.disabled = true;

    fetch(`<?php echo e(route('waybill.pickup', $order)); ?>`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            let message = 'Pickup berhasil diminta!';
            if (result.data && result.data.message) {
                message += '\n\n' + result.data.message;
            }

            // Show WhatsApp notification link if available
            if (result.whatsapp_link) {
                message += '\n\nKirim notifikasi WhatsApp ke customer?';
                if (confirm(message)) {
                    window.open(result.whatsapp_link, '_blank');
                }
            } else {
                alert(message);
            }

            closePickupModal();
            // Reload page to show updated status
            window.location.reload();
        } else {
            let errorMessage = 'Gagal meminta pickup: ' + result.message;

            // Show detailed validation errors if available
            if (result.errors) {
                errorMessage += '\n\nDetail error:';
                Object.keys(result.errors).forEach(field => {
                    errorMessage += '\n- ' + field + ': ' + result.errors[field].join(', ');
                });
            }

            alert(errorMessage);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Terjadi kesalahan saat meminta pickup');
    })
    .finally(() => {
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\HTML\pojiskripsi\resources\views/orders/waybill.blade.php ENDPATH**/ ?>