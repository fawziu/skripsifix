<?php $__env->startSection('title', 'Alamat Saya - Afiyah'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <!-- Header -->
    <div class="mb-8">
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h1 class="text-3xl font-bold text-gray-900">Alamat Saya</h1>
                <p class="mt-2 text-gray-600">Kelola alamat pengiriman Anda</p>
            </div>
            <div class="mt-4 sm:mt-0">
                <a href="<?php echo e(route('addresses.create')); ?>"
                   class="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors">
                    <i class="fas fa-plus mr-2"></i>
                    Tambah Alamat Baru
                </a>
            </div>
        </div>
    </div>

    <!-- Addresses List -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php $__empty_1 = true; $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 relative">
            <!-- Primary Badge -->
            <?php if($address->is_primary): ?>
            <div class="absolute top-4 right-4">
                <span class="inline-flex items-center px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                    <i class="fas fa-star mr-1"></i>
                    Utama
                </span>
            </div>
            <?php endif; ?>

            <!-- Address Type -->
            <div class="flex items-center mb-4">
                <div class="w-8 h-8 rounded-lg flex items-center justify-center mr-3
                    <?php if($address->type === 'home'): ?> bg-blue-100 text-blue-600
                    <?php elseif($address->type === 'office'): ?> bg-green-100 text-green-600
                    <?php elseif($address->type === 'warehouse'): ?> bg-orange-100 text-orange-600
                    <?php else: ?> bg-gray-100 text-gray-600 <?php endif; ?>">
                    <?php if($address->type === 'home'): ?>
                        <i class="fas fa-home"></i>
                    <?php elseif($address->type === 'office'): ?>
                        <i class="fas fa-building"></i>
                    <?php elseif($address->type === 'warehouse'): ?>
                        <i class="fas fa-warehouse"></i>
                    <?php else: ?>
                        <i class="fas fa-map-marker-alt"></i>
                    <?php endif; ?>
                </div>
                <div>
                    <h3 class="font-semibold text-gray-900"><?php echo e($address->label); ?></h3>
                    <p class="text-sm text-gray-500"><?php echo e($address->type_label); ?></p>
                </div>
            </div>

            <!-- Recipient Info -->
            <div class="mb-4">
                <p class="font-medium text-gray-900"><?php echo e($address->recipient_name); ?></p>
                <p class="text-sm text-gray-600"><?php echo e($address->phone); ?></p>
            </div>

            <!-- Address Details -->
            <div class="mb-4">
                <p class="text-sm text-gray-700 leading-relaxed"><?php echo e($address->address_line); ?></p>
                <p class="text-sm text-gray-600 mt-1">
                    <?php if($address->district): ?>
                        <span class="font-medium"><?php echo e($address->district->name); ?></span>,
                    <?php endif; ?>
                    <?php if($address->city): ?>
                        <span class="font-medium"><?php echo e($address->city->name); ?></span>
                        <?php if($address->city->type): ?>
                            <span class="text-xs text-gray-500">(<?php echo e($address->city->type); ?>)</span>
                        <?php endif; ?>
                        ,
                    <?php endif; ?>
                    <?php if($address->province): ?>
                        <span class="font-medium"><?php echo e($address->province->name); ?></span>
                    <?php endif; ?>
                    <?php if($address->postal_code): ?>
                        <br><span class="text-xs text-gray-500"><?php echo e($address->postal_code); ?></span>
                    <?php endif; ?>
                </p>
            </div>

            <!-- Actions -->
            <div class="flex items-center justify-between pt-4 border-t border-gray-200">
                <div class="flex space-x-2">
                    <?php if(!$address->is_primary): ?>
                    <form method="POST" action="<?php echo e(route('addresses.set-primary', $address)); ?>" class="inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="text-blue-600 hover:text-blue-800 text-sm font-medium">
                            <i class="fas fa-star mr-1"></i>
                            Jadikan Utama
                        </button>
                    </form>
                    <?php endif; ?>
                </div>
                <div class="flex items-center space-x-2">
                    <a href="<?php echo e(route('addresses.edit', $address)); ?>"
                       class="text-gray-600 hover:text-gray-800 transition-colors">
                        <i class="fas fa-edit"></i>
                    </a>
                    <form method="POST" action="<?php echo e(route('addresses.destroy', $address)); ?>" class="inline"
                          onsubmit="return confirm('Apakah Anda yakin ingin menghapus alamat ini?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="text-red-600 hover:text-red-800 transition-colors">
                            <i class="fas fa-trash"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-span-full">
            <div class="text-center py-12">
                <div class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-map-marker-alt text-gray-400 text-2xl"></i>
                </div>
                <h3 class="text-lg font-medium text-gray-900 mb-2">Belum ada alamat</h3>
                <p class="text-gray-500 mb-6">Tambahkan alamat pengiriman untuk memudahkan proses pemesanan</p>
                <a href="<?php echo e(route('addresses.create')); ?>"
                   class="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors">
                    <i class="fas fa-plus mr-2"></i>
                    Tambah Alamat Pertama
                </a>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Tips -->
    <?php if($addresses->count() > 0): ?>
    <div class="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
        <div class="flex items-start">
            <div class="flex-shrink-0">
                <i class="fas fa-info-circle text-blue-600 text-lg"></i>
            </div>
            <div class="ml-3">
                <h3 class="text-sm font-medium text-blue-900">Tips Penggunaan Alamat</h3>
                <div class="mt-2 text-sm text-blue-700">
                    <ul class="list-disc list-inside space-y-1">
                        <li>Pastikan alamat utama sudah benar untuk pengiriman default</li>
                        <li>Gunakan label yang mudah diingat (misal: "Rumah Jakarta", "Kantor Bandung")</li>
                        <li>Periksa nomor telepon penerima agar kurir dapat menghubungi</li>
                        <li>Alamat yang tidak aktif tidak akan muncul saat membuat pesanan</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\HTML\pojiskripsi\resources\views/addresses/index.blade.php ENDPATH**/ ?>