<?php $__env->startSection('title', 'Detail Keluhan - Afiyah'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <!-- Header -->
    <div class="mb-8">
        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-3xl font-bold text-gray-900">Detail Keluhan</h1>
                <p class="mt-2 text-gray-600">Informasi lengkap keluhan pengiriman</p>
            </div>
            <div class="flex items-center space-x-3">
                <a href="<?php echo e(route('complaints.index')); ?>"
                   class="inline-flex items-center px-4 py-2 bg-gray-600 text-white text-sm font-medium rounded-lg hover:bg-gray-700 transition-colors">
                    <i class="fas fa-arrow-left mr-2"></i>
                    Kembali
                </a>
                <?php if(Auth::user()->isAdmin() || Auth::user()->id === $complaint->user_id): ?>
                <a href="<?php echo e(route('complaints.edit', $complaint)); ?>"
                   class="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors">
                    <i class="fas fa-edit mr-2"></i>
                    Edit
                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Complaint Details -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Main Content -->
        <div class="lg:col-span-2 space-y-6">
            <!-- Complaint Card -->
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <div class="flex items-start justify-between mb-4">
                    <div>
                        <h2 class="text-xl font-semibold text-gray-900"><?php echo e($complaint->title); ?></h2>
                        <p class="text-sm text-gray-500 mt-1">
                            Dibuat pada <?php echo e($complaint->created_at->format('d M Y H:i')); ?>

                        </p>
                    </div>
                    <div class="flex items-center">
                        <?php switch($complaint->status):
                            case ('pending'): ?>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                                    <i class="fas fa-clock mr-1"></i>
                                    Menunggu
                                </span>
                                <?php break; ?>
                            <?php case ('in_progress'): ?>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                    <i class="fas fa-spinner mr-1"></i>
                                    Sedang Diproses
                                </span>
                                <?php break; ?>
                            <?php case ('resolved'): ?>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                    <i class="fas fa-check mr-1"></i>
                                    Selesai
                                </span>
                                <?php break; ?>
                            <?php case ('closed'): ?>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                    <i class="fas fa-times mr-1"></i>
                                    Ditutup
                                </span>
                                <?php break; ?>
                            <?php default: ?>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                    <?php echo e(ucfirst($complaint->status)); ?>

                                </span>
                        <?php endswitch; ?>
                    </div>
                </div>

                <!-- Complaint Description -->
                <div class="mb-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-2">Deskripsi Keluhan</h3>
                    <div class="bg-gray-50 rounded-lg p-4">
                        <p class="text-gray-700 leading-relaxed"><?php echo e($complaint->description); ?></p>
                    </div>
                </div>

                <!-- Related Order -->
                <?php if($complaint->order): ?>
                <div class="mb-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-2">Pesanan Terkait</h3>
                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="font-medium text-blue-900">Order #<?php echo e($complaint->order->id); ?></p>
                                <p class="text-sm text-blue-700"><?php echo e($complaint->order->item_description); ?></p>
                                <p class="text-sm text-blue-600">
                                    Status:
                                    <span class="font-medium"><?php echo e(ucfirst($complaint->order->status)); ?></span>
                                </p>
                            </div>
                            <a href="<?php echo e(route('orders.show', $complaint->order)); ?>"
                               class="inline-flex items-center px-3 py-1 bg-blue-600 text-white text-xs font-medium rounded hover:bg-blue-700 transition-colors">
                                <i class="fas fa-eye mr-1"></i>
                                Lihat
                            </a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Complaint Category -->
                <div class="mb-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-2">Kategori Keluhan</h3>
                    <div class="flex items-center">
                        <?php switch($complaint->category):
                            case ('delivery_delay'): ?>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                                    <i class="fas fa-clock mr-1"></i>
                                    Keterlambatan Pengiriman
                                </span>
                                <?php break; ?>
                            <?php case ('damaged_item'): ?>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                    <i class="fas fa-exclamation-triangle mr-1"></i>
                                    Barang Rusak
                                </span>
                                <?php break; ?>
                            <?php case ('wrong_item'): ?>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                                    <i class="fas fa-exchange-alt mr-1"></i>
                                    Barang Salah
                                </span>
                                <?php break; ?>
                            <?php case ('service_quality'): ?>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                                    <i class="fas fa-star mr-1"></i>
                                    Kualitas Layanan
                                </span>
                                <?php break; ?>
                            <?php case ('other'): ?>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                    <i class="fas fa-question-circle mr-1"></i>
                                    Lainnya
                                </span>
                                <?php break; ?>
                            <?php default: ?>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                    <?php echo e(ucfirst($complaint->category)); ?>

                                </span>
                        <?php endswitch; ?>
                    </div>
                </div>

                <!-- Priority Level -->
                <div class="mb-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-2">Tingkat Prioritas</h3>
                    <div class="flex items-center">
                        <?php switch($complaint->priority):
                            case ('low'): ?>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                    <i class="fas fa-arrow-down mr-1"></i>
                                    Rendah
                                </span>
                                <?php break; ?>
                            <?php case ('medium'): ?>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                                    <i class="fas fa-minus mr-1"></i>
                                    Sedang
                                </span>
                                <?php break; ?>
                            <?php case ('high'): ?>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                                    <i class="fas fa-arrow-up mr-1"></i>
                                    Tinggi
                                </span>
                                <?php break; ?>
                            <?php case ('urgent'): ?>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                    <i class="fas fa-exclamation-triangle mr-1"></i>
                                    Urgent
                                </span>
                                <?php break; ?>
                            <?php default: ?>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                    <?php echo e(ucfirst($complaint->priority)); ?>

                                </span>
                        <?php endswitch; ?>
                    </div>
                </div>

                <!-- Admin Response -->
                <?php if($complaint->admin_response): ?>
                <div class="mb-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-2">Respon Admin</h3>
                    <div class="bg-green-50 border border-green-200 rounded-lg p-4">
                        <div class="flex items-start">
                            <div class="flex-shrink-0">
                                <i class="fas fa-user-tie text-green-600 text-lg"></i>
                            </div>
                            <div class="ml-3">
                                <p class="text-sm font-medium text-green-900">Admin Response</p>
                                <p class="text-sm text-green-700 mt-1"><?php echo e($complaint->admin_response); ?></p>
                                <?php if($complaint->admin_response_at): ?>
                                <p class="text-xs text-green-600 mt-2">
                                    Direspon pada <?php echo e($complaint->admin_response_at->format('d M Y H:i')); ?>

                                </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Resolution Notes -->
                <?php if($complaint->resolution_notes): ?>
                <div class="mb-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-2">Catatan Penyelesaian</h3>
                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <p class="text-blue-700"><?php echo e($complaint->resolution_notes); ?></p>
                        <?php if($complaint->resolved_at): ?>
                        <p class="text-xs text-blue-600 mt-2">
                            Diselesaikan pada <?php echo e($complaint->resolved_at->format('d M Y H:i')); ?>

                        </p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="space-y-6">
            <!-- User Information -->
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Informasi Pelapor</h3>
                <div class="space-y-3">
                    <div>
                        <p class="text-sm font-medium text-gray-500">Nama</p>
                        <p class="text-sm text-gray-900"><?php echo e($complaint->user->name); ?></p>
                    </div>
                    <div>
                        <p class="text-sm font-medium text-gray-500">Email</p>
                        <p class="text-sm text-gray-900"><?php echo e($complaint->user->email); ?></p>
                    </div>
                    <div>
                        <p class="text-sm font-medium text-gray-500">Telepon</p>
                        <p class="text-sm text-gray-900"><?php echo e($complaint->user->phone); ?></p>
                    </div>
                    <div>
                        <p class="text-sm font-medium text-gray-500">Role</p>
                        <p class="text-sm text-gray-900"><?php echo e($complaint->user->role->display_name); ?></p>
                    </div>
                </div>
            </div>

            <!-- Complaint Timeline -->
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Timeline</h3>
                <div class="space-y-4">
                    <div class="flex items-start">
                        <div class="flex-shrink-0">
                            <div class="w-3 h-3 bg-blue-600 rounded-full"></div>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm font-medium text-gray-900">Keluhan Dibuat</p>
                            <p class="text-xs text-gray-500"><?php echo e($complaint->created_at->format('d M Y H:i')); ?></p>
                        </div>
                    </div>

                    <?php if($complaint->admin_response_at): ?>
                    <div class="flex items-start">
                        <div class="flex-shrink-0">
                            <div class="w-3 h-3 bg-green-600 rounded-full"></div>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm font-medium text-gray-900">Admin Merespon</p>
                            <p class="text-xs text-gray-500"><?php echo e($complaint->admin_response_at->format('d M Y H:i')); ?></p>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if($complaint->resolved_at): ?>
                    <div class="flex items-start">
                        <div class="flex-shrink-0">
                            <div class="w-3 h-3 bg-purple-600 rounded-full"></div>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm font-medium text-gray-900">Diselesaikan</p>
                            <p class="text-xs text-gray-500"><?php echo e($complaint->resolved_at->format('d M Y H:i')); ?></p>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if($complaint->updated_at && $complaint->updated_at != $complaint->created_at): ?>
                    <div class="flex items-start">
                        <div class="flex-shrink-0">
                            <div class="w-3 h-3 bg-gray-600 rounded-full"></div>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm font-medium text-gray-900">Terakhir Diupdate</p>
                            <p class="text-xs text-gray-500"><?php echo e($complaint->updated_at->format('d M Y H:i')); ?></p>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Quick Actions -->
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\HTML\pojiskripsi\resources\views/complaints/show.blade.php ENDPATH**/ ?>