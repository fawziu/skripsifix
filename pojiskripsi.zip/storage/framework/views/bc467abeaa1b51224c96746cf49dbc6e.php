<?php $__env->startSection('title', 'Track Order - Afiyah'); ?>

<?php $__env->startSection('content'); ?>
<?php if(!Auth::user()->isAdmin()): ?>
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
            <div class="flex items-center">
                <i class="fas fa-exclamation-triangle mr-2"></i>
                <span>Anda tidak memiliki akses ke halaman ini.</span>
            </div>
        </div>
        <div class="mt-4">
            <a href="<?php echo e(route('orders.show', $order)); ?>" class="text-blue-600 hover:text-blue-800">
                <i class="fas fa-arrow-left mr-2"></i>
                Kembali ke Detail Pesanan
            </a>
        </div>
    </div>
<?php else: ?>

<!-- Debug Information for Admin -->
<?php if(config('app.debug')): ?>
<div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
    <div class="bg-yellow-100 border border-yellow-400 text-yellow-800 px-4 py-3 rounded">
        <div class="flex items-center justify-between">
            <div class="flex items-center">
                <i class="fas fa-bug mr-2"></i>
                <span class="font-medium">Debug Info (Development Only)</span>
            </div>
            <button onclick="this.parentElement.parentElement.remove()" class="text-yellow-600 hover:text-yellow-800">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="mt-2 text-sm">
            <div><strong>Order ID:</strong> <?php echo e($order->id); ?></div>
            <div><strong>Shipping Method:</strong> <?php echo e($order->shipping_method ?? 'NULL'); ?></div>
            <div><strong>Tracking Number:</strong> <?php echo e($order->tracking_number ?? 'NULL'); ?></div>
            <div><strong>Courier Service:</strong> <?php echo e($order->courier_service ?? 'NULL'); ?></div>
            <div><strong>Status:</strong> <?php echo e($order->status ?? 'NULL'); ?></div>
            <div><strong>Customer:</strong> <?php echo e($order->customer->name ?? 'NULL'); ?></div>
            <div><strong>Courier:</strong> <?php echo e($order->courier->name ?? 'NULL'); ?></div>
        </div>
    </div>
</div>
<?php endif; ?>
<div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <!-- Header -->
    <div class="mb-8">
        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-3xl font-bold text-gray-900">Lacak Pesanan #<?php echo e($order->id); ?></h1>
                <p class="mt-2 text-gray-600">Informasi tracking pengiriman</p>
            </div>
            <a href="<?php echo e(route('orders.show', $order)); ?>"
               class="inline-flex items-center px-4 py-2 bg-gray-600 text-white text-sm font-medium rounded-lg hover:bg-gray-700 transition-colors">
                <i class="fas fa-arrow-left mr-2"></i>
                Kembali ke Detail
            </a>
        </div>
    </div>

    <!-- Order Info -->
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
        <div class="flex items-center justify-between mb-4">
            <div class="flex items-center">
                <i class="fas fa-box text-blue-500 text-xl mr-3"></i>
                <h3 class="text-lg font-semibold text-gray-900">Informasi Pesanan</h3>
            </div>
            <!-- Debug Info for Admin -->
            <div class="text-xs text-gray-500 bg-gray-100 px-3 py-2 rounded">
                <div><strong>Shipping Method:</strong> <?php echo e($order->shipping_method ?? 'N/A'); ?></div>
                <div><strong>Tracking Number:</strong> <?php echo e($order->tracking_number ?? 'N/A'); ?></div>
                <div><strong>Courier Service:</strong> <?php echo e($order->courier_service ?? 'N/A'); ?></div>
            </div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <span class="text-sm font-medium text-gray-600">Order Number:</span>
                <p class="text-sm text-gray-900 mt-1 font-mono"><?php echo e($order->order_number); ?></p>
            </div>
            <div>
                <span class="text-sm font-medium text-gray-600">Status:</span>
                <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full mt-1
                    <?php if($order->status === 'pending'): ?> bg-yellow-100 text-yellow-800
                    <?php elseif($order->status === 'confirmed'): ?> bg-blue-100 text-blue-800
                    <?php elseif($order->status === 'assigned'): ?> bg-indigo-100 text-indigo-800
                    <?php elseif($order->status === 'picked_up'): ?> bg-purple-100 text-purple-800
                    <?php elseif($order->status === 'in_transit'): ?> bg-orange-100 text-orange-800
                    <?php elseif($order->status === 'delivered'): ?> bg-green-100 text-green-800
                    <?php else: ?> bg-red-100 text-red-800 <?php endif; ?>">
                    <?php echo e(ucfirst(str_replace('_', ' ', $order->status))); ?>

                </span>
            </div>
            <div>
                <span class="text-sm font-medium text-gray-600">Metode Pengiriman:</span>
                <p class="text-sm text-gray-900 mt-1">
                    <?php if($order->shipping_method === 'rajaongkir'): ?>
                        <span class="inline-flex items-center">
                            <i class="fas fa-shipping-fast text-green-500 mr-2"></i>
                            RajaOngkir
                        </span>
                    <?php else: ?>
                        <span class="inline-flex items-center">
                            <i class="fas fa-truck text-blue-500 mr-2"></i>
                            Manual
                        </span>
                    <?php endif; ?>
                </p>
            </div>
            <div>
                <span class="text-sm font-medium text-gray-600">Customer:</span>
                <p class="text-sm text-gray-900 mt-1"><?php echo e($order->customer->name ?? 'N/A'); ?></p>
            </div>
            <?php if($order->tracking_number): ?>
            <div>
                <span class="text-sm font-medium text-gray-600">Tracking Number:</span>
                <p class="text-sm text-gray-900 mt-1 font-mono bg-gray-100 px-2 py-1 rounded"><?php echo e($order->tracking_number); ?></p>
            </div>
            <?php endif; ?>
            <?php if($order->courier_service): ?>
            <div>
                <span class="text-sm font-medium text-gray-600">Courier Service:</span>
                <p class="text-sm text-gray-900 mt-1 font-medium"><?php echo e(strtoupper($order->courier_service)); ?></p>
            </div>
            <?php endif; ?>
            <?php if($order->courier): ?>
            <div>
                <span class="text-sm font-medium text-gray-600">Kurir Internal:</span>
                <p class="text-sm text-gray-900 mt-1"><?php echo e($order->courier->name); ?></p>
            </div>
            <?php endif; ?>
        </div>

        <!-- Order Details -->
        <div class="mt-6 pt-6 border-t border-gray-200">
            <h4 class="text-md font-medium text-gray-900 mb-3">Detail Item</h4>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <span class="text-sm font-medium text-gray-600">Item:</span>
                    <p class="text-sm text-gray-900 mt-1"><?php echo e($order->item_description); ?></p>
                </div>
                <div>
                    <span class="text-sm font-medium text-gray-600">Berat:</span>
                    <p class="text-sm text-gray-900 mt-1"><?php echo e($order->item_weight); ?> kg</p>
                </div>
                <div>
                    <span class="text-sm font-medium text-gray-600">Total Biaya:</span>
                    <p class="text-sm text-gray-900 mt-1 font-medium">Rp <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Tracking Information -->
    <div id="tracking-container">
        <!-- Loading State -->
        <div id="loading-state" class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div class="flex items-center justify-center">
                <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                <span class="ml-3 text-gray-600">Memuat informasi tracking...</span>
            </div>
        </div>

        <!-- Error State -->
        <div id="error-state" class="hidden bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div class="text-center">
                <i class="fas fa-exclamation-triangle text-red-500 text-3xl mb-4"></i>
                <h3 class="text-lg font-semibold text-gray-900 mb-2">Gagal Memuat Tracking</h3>
                <p class="text-gray-600 mb-4" id="error-message">Terjadi kesalahan saat memuat informasi tracking.</p>
                <button onclick="loadTracking()"
                        class="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors">
                    <i class="fas fa-refresh mr-2"></i>
                    Coba Lagi
                </button>
            </div>
        </div>

        <!-- Manual Tracking Info -->
        <div id="manual-tracking" class="hidden bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div class="text-center">
                <i class="fas fa-truck text-blue-500 text-3xl mb-4"></i>
                <h3 class="text-lg font-semibold text-gray-900 mb-2">Pengiriman Manual</h3>
                <p class="text-gray-600 mb-4">
                    <?php if($order->shipping_method === 'manual'): ?>
                        Pesanan ini menggunakan metode pengiriman manual dengan kurir internal.
                    <?php else: ?>
                        Pesanan ini tidak mendukung tracking RajaOngkir atau tracking number tidak tersedia.
                    <?php endif; ?>
                </p>

                                <!-- Order Status Timeline -->
                <div class="bg-gray-50 rounded-lg p-6 mt-6">
                    <h4 class="font-medium text-gray-900 mb-4 text-center">Status Pengiriman</h4>
                    <div class="space-y-4">
                        <?php
                            $statuses = [
                                'pending' => ['icon' => 'clock', 'color' => 'yellow', 'label' => 'Menunggu Konfirmasi'],
                                'confirmed' => ['icon' => 'check-circle', 'color' => 'blue', 'label' => 'Dikonfirmasi'],
                                'assigned' => ['icon' => 'user-tie', 'color' => 'indigo', 'label' => 'Ditugaskan ke Kurir'],
                                'picked_up' => ['icon' => 'truck', 'color' => 'purple', 'label' => 'Diambil Kurir'],
                                'in_transit' => ['icon' => 'route', 'color' => 'orange', 'label' => 'Dalam Perjalanan'],
                                'delivered' => ['icon' => 'check-double', 'color' => 'green', 'label' => 'Terkirim'],
                                'failed' => ['icon' => 'times-circle', 'color' => 'red', 'label' => 'Gagal']
                            ];
                        ?>
                        
                        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $isActive = $order->status === $status;
                                $isCompleted = array_search($order->status, array_keys($statuses)) >= array_search($status, array_keys($statuses));
                                $iconColor = $isActive ? $info['color'] : ($isCompleted ? 'green' : 'gray');
                                $bgColor = $isActive ? $info['color'] : ($isCompleted ? 'green' : 'gray');
                            ?>
                            
                            <div class="flex items-center space-x-3">
                                <div class="flex-shrink-0">
                                    <div class="w-8 h-8 bg-<?php echo e($bgColor); ?>-100 rounded-full flex items-center justify-center">
                                        <i class="fas fa-<?php echo e($info['icon']); ?> text-<?php echo e($iconColor); ?>-600 text-sm"></i>
                                    </div>
                                </div>
                                <div class="flex-1">
                                    <p class="text-sm font-medium text-gray-900"><?php echo e($info['label']); ?></p>
                                    <?php if($isActive): ?>
                                        <p class="text-xs text-<?php echo e($bgColor); ?>-600 font-medium">Status Saat Ini</p>
                                    <?php endif; ?>
                                </div>
                                <?php if($isCompleted): ?>
                                    <div class="flex-shrink-0">
                                        <i class="fas fa-check text-green-500"></i>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php if($status !== 'failed' && $status !== 'delivered'): ?>
                                <div class="ml-4 border-l-2 border-gray-200 h-4"></div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <!-- Shipping Method Info -->
                <div class="bg-yellow-50 rounded-lg p-4 mt-6">
                    <h4 class="font-medium text-yellow-900 mb-2">Informasi Metode Pengiriman</h4>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div>
                            <span class="text-yellow-700">Metode:</span>
                            <p class="text-yellow-900 font-medium">
                                <?php if($order->shipping_method === 'rajaongkir'): ?>
                                    <span class="inline-flex items-center">
                                        <i class="fas fa-shipping-fast text-green-500 mr-2"></i>
                                        RajaOngkir
                                    </span>
                                <?php elseif($order->shipping_method === 'manual'): ?>
                                    <span class="inline-flex items-center">
                                        <i class="fas fa-truck text-blue-500 mr-2"></i>
                                        Manual
                                    </span>
                                <?php else: ?>
                                    <span class="text-gray-600">Tidak Diketahui</span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div>
                            <span class="text-yellow-700">Alasan Manual:</span>
                            <p class="text-yellow-900">
                                <?php if($order->shipping_method === 'rajaongkir' && !$order->tracking_number): ?>
                                    Tracking number tidak tersedia
                                <?php elseif($order->shipping_method === 'manual'): ?>
                                    Pengiriman dengan kurir internal
                                <?php else: ?>
                                    <?php echo e($order->shipping_method ?? 'N/A'); ?>

                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Courier Information -->
                <?php if($order->courier): ?>
                <div class="bg-blue-50 rounded-lg p-4 mt-6">
                    <h4 class="font-medium text-blue-900 mb-2">Informasi Kurir</h4>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div>
                            <span class="text-blue-700">Nama Kurir:</span>
                            <p class="text-blue-900 font-medium"><?php echo e($order->courier->name); ?></p>
                        </div>
                        <div>
                            <span class="text-blue-700">Status:</span>
                            <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full
                                <?php if($order->status === 'assigned'): ?> bg-blue-100 text-blue-800
                                <?php elseif($order->status === 'picked_up'): ?> bg-purple-100 text-purple-800
                                <?php elseif($order->status === 'in_transit'): ?> bg-orange-100 text-orange-800
                                <?php elseif($order->status === 'delivered'): ?> bg-green-100 text-green-800
                                <?php else: ?> bg-gray-100 text-gray-800 <?php endif; ?>">
                                <?php echo e(ucfirst(str_replace('_', ' ', $order->status))); ?>

                            </span>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Order Details -->
                <div class="bg-gray-50 rounded-lg p-4 mt-6">
                    <h4 class="font-medium text-gray-900 mb-2">Detail Pesanan</h4>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div>
                            <span class="text-gray-600">Item:</span>
                            <p class="text-gray-900"><?php echo e($order->item_description); ?></p>
                        </div>
                        <div>
                            <span class="text-gray-600">Berat:</span>
                            <p class="text-gray-900"><?php echo e($order->item_weight); ?> kg</p>
                        </div>
                        <div>
                            <span class="text-gray-600">Alamat Tujuan:</span>
                            <p class="text-gray-900"><?php echo e(Str::limit($order->destination_address, 50)); ?></p>
                        </div>
                        <div>
                            <span class="text-gray-600">Total Biaya:</span>
                            <p class="text-gray-900 font-medium">Rp <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?></p>
                        </div>
                    </div>
                </div>

                <!-- Admin Actions -->
                <div class="bg-blue-50 rounded-lg p-4 mt-6">
                    <h4 class="font-medium text-blue-900 mb-3">Aksi Admin</h4>
                    <div class="flex flex-wrap gap-3">
                        <a href="<?php echo e(route('orders.show', $order)); ?>"
                           class="inline-flex items-center px-3 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors">
                            <i class="fas fa-eye mr-2"></i>
                            Lihat Detail Lengkap
                        </a>
                        <?php if($order->courier): ?>
                        <a href="<?php echo e(route('courier.orders.show', $order)); ?>"
                           class="inline-flex items-center px-3 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-colors">
                            <i class="fas fa-truck mr-2"></i>
                            Update Status Kurir
                        </a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('complaints.index')); ?>"
                           class="inline-flex items-center px-3 py-2 bg-red-600 text-white text-sm font-medium rounded-lg hover:bg-red-700 transition-colors">
                            <i class="fas fa-exclamation-triangle mr-2"></i>
                            Keluhan
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- RajaOngkir Tracking Result -->
        <div id="rajaongkir-tracking" class="hidden">
            <!-- Shipment Info -->
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
                <div class="flex items-center mb-4">
                    <i class="fas fa-shipping-fast text-green-500 text-xl mr-3"></i>
                    <h3 class="text-lg font-semibold text-gray-900">Informasi Pengiriman RajaOngkir</h3>
                </div>
                <div id="shipment-info" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <!-- Will be populated by JavaScript -->
                </div>
            </div>

            <!-- Tracking Timeline -->
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <div class="flex items-center mb-4">
                    <i class="fas fa-route text-blue-500 text-xl mr-3"></i>
                    <h3 class="text-lg font-semibold text-gray-900">Timeline Pengiriman</h3>
                </div>
                <div id="tracking-timeline" class="space-y-4">
                    <!-- Will be populated by JavaScript -->
                </div>
            </div>

            <!-- Additional Admin Info -->
            <div class="bg-blue-50 rounded-lg border border-blue-200 p-6 mt-6">
                <div class="flex items-center mb-4">
                    <i class="fas fa-info-circle text-blue-500 text-xl mr-3"></i>
                    <h3 class="text-lg font-semibold text-blue-900">Informasi Admin</h3>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                        <span class="text-blue-700 font-medium">Metode Pengiriman:</span>
                        <p class="text-blue-900">RajaOngkir - <?php echo e(strtoupper($order->courier_service ?? 'N/A')); ?></p>
                    </div>
                    <div>
                        <span class="text-blue-700 font-medium">Tracking Number:</span>
                        <p class="text-blue-900 font-mono"><?php echo e($order->tracking_number ?? 'N/A'); ?></p>
                    </div>
                    <div>
                        <span class="text-blue-700 font-medium">Status Order:</span>
                        <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full
                            <?php if($order->status === 'pending'): ?> bg-yellow-100 text-yellow-800
                            <?php elseif($order->status === 'confirmed'): ?> bg-blue-100 text-blue-800
                            <?php elseif($order->status === 'assigned'): ?> bg-indigo-100 text-indigo-800
                            <?php elseif($order->status === 'picked_up'): ?> bg-purple-100 text-purple-800
                            <?php elseif($order->status === 'in_transit'): ?> bg-orange-100 text-orange-800
                            <?php elseif($order->status === 'delivered'): ?> bg-green-100 text-green-800
                            <?php else: ?> bg-red-100 text-red-800 <?php endif; ?>">
                            <?php echo e(ucfirst(str_replace('_', ' ', $order->status))); ?>

                        </span>
                    </div>
                    <div>
                        <span class="text-blue-700 font-medium">Biaya Pengiriman:</span>
                        <p class="text-blue-900">Rp <?php echo e(number_format($order->shipping_cost ?? 0, 0, ',', '.')); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    loadTracking();
});

function loadTracking() {
    const loadingState = document.getElementById('loading-state');
    const errorState = document.getElementById('error-state');
    const manualTracking = document.getElementById('manual-tracking');
    const rajaongkirTracking = document.getElementById('rajaongkir-tracking');

    // Show loading
    loadingState.classList.remove('hidden');
    errorState.classList.add('hidden');
    manualTracking.classList.add('hidden');
    rajaongkirTracking.classList.add('hidden');

    // Check if order supports RajaOngkir tracking
    const orderData = <?php echo json_encode($order, 15, 512) ?>;

    console.log('Order Data:', orderData);
    console.log('Shipping Method:', orderData.shipping_method);
    console.log('Tracking Number:', orderData.tracking_number);

    // Check if order supports RajaOngkir tracking
    if (orderData.shipping_method === 'rajaongkir' && orderData.tracking_number) {
        console.log('Loading RajaOngkir tracking...');
        // Continue with RajaOngkir tracking
    } else {
        console.log('Showing manual tracking...');
        loadingState.classList.add('hidden');
        manualTracking.classList.remove('hidden');
        return;
    }

    // Fetch tracking data
    fetch(`/api/orders/${orderData.id}/track`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        }
    })
    .then(response => {
        console.log('API Response:', response);
        return response.json();
    })
    .then(data => {
        console.log('API Data:', data);
        loadingState.classList.add('hidden');

        if (data.success && data.data) {
            displayRajaOngkirTracking(data.data);
        } else {
            showError(data.message || 'Gagal memuat informasi tracking');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        loadingState.classList.add('hidden');
        showError('Terjadi kesalahan saat memuat informasi tracking');
    });
}

function displayRajaOngkirTracking(trackingData) {
    const rajaongkirTracking = document.getElementById('rajaongkir-tracking');
    const shipmentInfo = document.getElementById('shipment-info');
    const trackingTimeline = document.getElementById('tracking-timeline');

    // Display shipment info
    if (trackingData.summary) {
        const summary = trackingData.summary;
        shipmentInfo.innerHTML = `
            <div>
                <span class="text-sm font-medium text-gray-600">Status Pengiriman:</span>
                <p class="text-sm text-gray-900 mt-1 font-medium">${summary.status || 'N/A'}</p>
            </div>
            <div>
                <span class="text-sm font-medium text-gray-600">Kurir:</span>
                <p class="text-sm text-gray-900 mt-1">${summary.courier_name || 'N/A'}</p>
            </div>
            <div>
                <span class="text-sm font-medium text-gray-600">Asal:</span>
                <p class="text-sm text-gray-900 mt-1">${summary.origin || 'N/A'}</p>
            </div>
            <div>
                <span class="text-sm font-medium text-gray-600">Tujuan:</span>
                <p class="text-sm text-gray-900 mt-1">${summary.destination || 'N/A'}</p>
            </div>
            <div>
                <span class="text-sm font-medium text-gray-600">Estimasi:</span>
                <p class="text-sm text-gray-900 mt-1">${summary.etd || 'N/A'}</p>
            </div>
            <div>
                <span class="text-sm font-medium text-gray-600">Berat:</span>
                <p class="text-sm text-gray-900 mt-1">${summary.weight || 'N/A'} kg</p>
            </div>
        `;
    }

    // Display tracking timeline
    if (trackingData.manifest && trackingData.manifest.length > 0) {
        trackingTimeline.innerHTML = trackingData.manifest.map((item, index) => `
            <div class="flex items-start space-x-3">
                <div class="flex-shrink-0">
                    <div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <i class="fas fa-truck text-blue-600 text-sm"></i>
                    </div>
                </div>
                <div class="flex-1 min-w-0">
                    <p class="text-sm font-medium text-gray-900">${item.manifest_description || 'Update Status'}</p>
                    <div class="flex items-center space-x-4 mt-1">
                        <span class="text-sm text-gray-500">
                            <i class="fas fa-calendar mr-1"></i>
                            ${item.manifest_date || 'N/A'}
                        </span>
                        <span class="text-sm text-gray-500">
                            <i class="fas fa-clock mr-1"></i>
                            ${item.manifest_time || 'N/A'}
                        </span>
                    </div>
                    ${item.city_name ? `
                        <div class="mt-2 inline-flex items-center px-2 py-1 bg-gray-100 rounded-full">
                            <i class="fas fa-map-marker-alt text-gray-500 text-xs mr-1"></i>
                            <span class="text-xs text-gray-700">${item.city_name}</span>
                        </div>
                    ` : ''}
                </div>
            </div>
            ${index < trackingData.manifest.length - 1 ? '<div class="ml-4 border-l-2 border-gray-200 h-4"></div>' : ''}
        `).join('');
    } else {
        trackingTimeline.innerHTML = `
            <div class="text-center text-gray-500 py-8">
                <i class="fas fa-info-circle text-3xl mb-3"></i>
                <p class="text-lg font-medium">Belum ada informasi tracking yang tersedia</p>
                <p class="text-sm text-gray-400 mt-1">Tracking information akan muncul setelah kurir mulai mengirimkan paket</p>
            </div>
        `;
    }

    rajaongkirTracking.classList.remove('hidden');
}

function showError(message) {
    const errorState = document.getElementById('error-state');
    const errorMessage = document.getElementById('error-message');

    errorMessage.textContent = message;
    errorState.classList.remove('hidden');
}
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\HTML\pojiskripsi\resources\views/orders/track.blade.php ENDPATH**/ ?>